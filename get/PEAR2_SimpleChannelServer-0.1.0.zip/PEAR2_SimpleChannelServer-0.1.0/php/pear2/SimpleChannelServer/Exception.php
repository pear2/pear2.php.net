<?php
namespace pear2\SimpleChannelServer;
class Exception extends \Exception {}