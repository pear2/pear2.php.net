<?php
namespace pear2\Pyrus\Developer\Runphpt;
class Exception extends \PEAR2_Exception {}