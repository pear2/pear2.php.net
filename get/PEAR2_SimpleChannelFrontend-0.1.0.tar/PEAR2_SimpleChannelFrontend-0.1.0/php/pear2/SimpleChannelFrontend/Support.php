<?php
namespace pear2\SimpleChannelFrontend;
class Support
{
    
}
?>
