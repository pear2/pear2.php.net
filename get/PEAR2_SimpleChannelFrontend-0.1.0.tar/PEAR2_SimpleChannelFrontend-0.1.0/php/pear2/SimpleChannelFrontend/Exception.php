<?php
namespace pear2\SimpleChannelFrontend;
interface Exception{}
?>