<?php
namespace pear2\Templates\Savant;

class UnexpecteValueException implements Exception extends \UnexpectedValueException
{

}
