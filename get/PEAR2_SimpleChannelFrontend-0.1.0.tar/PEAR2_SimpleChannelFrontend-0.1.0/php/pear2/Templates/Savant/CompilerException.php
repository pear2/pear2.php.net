<?php
namespace pear2\Templates\Savant;

class CompilerException extends \Exception implements Exception {}
?>