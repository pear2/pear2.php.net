<?php
echo $context->var1;
?>