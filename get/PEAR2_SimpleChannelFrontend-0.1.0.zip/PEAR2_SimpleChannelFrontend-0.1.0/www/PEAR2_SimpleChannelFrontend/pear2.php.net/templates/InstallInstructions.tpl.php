<h3>Installation</h3>
<ol class="instructions">
    <li><code>$>php pyrus.phar channel-discover <?php echo pear2\SimpleChannelFrontend\Main::$channel->name; ?></code></li>
    <li><code>$>php pyrus.phar install <?php echo $context; ?></code></li>
</ol>
