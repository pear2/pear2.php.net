<?php header('HTTP/1.0 404 Not Found'); ?>
<h1>WHOAH Nelly.</h1>
<p>That view doesn't exist!</p>