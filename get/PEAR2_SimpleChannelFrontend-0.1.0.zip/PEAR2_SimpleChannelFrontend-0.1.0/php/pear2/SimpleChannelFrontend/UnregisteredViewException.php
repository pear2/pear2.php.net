<?php
namespace pear2\SimpleChannelFrontend;
class UnregisteredViewException extends \UnexpectedValueException implements Exception
{
    
}
?>