<?php
namespace pear2\Templates\Savant;

interface Exception
{

}
?>