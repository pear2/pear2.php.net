<?php
namespace pear2\Templates\Savant;

class TemplateException extends \Exception implements Exception {}
?>