<?php

namespace pear2\Templates\Savant;

interface MapperInterface
{
    function map($name);
}