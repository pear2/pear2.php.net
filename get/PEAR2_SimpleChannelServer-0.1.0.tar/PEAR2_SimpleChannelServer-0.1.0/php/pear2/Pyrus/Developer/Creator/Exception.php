<?php
namespace pear2\Pyrus\Developer\Creator;
class Exception extends \pear2\Exception {}