<?php
namespace pear2\SimpleChannelServer\Categories;
class Exception extends \Exception {}