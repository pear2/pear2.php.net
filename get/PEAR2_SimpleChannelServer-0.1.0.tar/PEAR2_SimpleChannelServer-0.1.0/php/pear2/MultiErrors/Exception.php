<?php
namespace pear2\MultiErrors;
class Exception extends \pear2\Exception {}