<?php
namespace pear2\HTTP\Request;
class Exception extends \Exception {
}
