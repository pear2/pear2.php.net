<?php
class PEAR2_HTTP_Request_Exception extends \pear2\Exception {
}
