<?php
namespace pear2\Pyrus\Developer\CoverageAnalyzer {
class Exception extends \Exception {}
}
?>
