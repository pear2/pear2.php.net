<?php
namespace pear2\Pyrus\Developer\Runphpt;
class Exception extends \pear2\Exception {}