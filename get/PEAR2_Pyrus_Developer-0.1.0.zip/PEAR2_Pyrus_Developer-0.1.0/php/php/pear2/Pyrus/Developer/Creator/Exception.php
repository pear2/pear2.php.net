<?php
namespace pear2\Pyrus\Developer\Creator;
class Exception extends \PEAR2_Exception {}