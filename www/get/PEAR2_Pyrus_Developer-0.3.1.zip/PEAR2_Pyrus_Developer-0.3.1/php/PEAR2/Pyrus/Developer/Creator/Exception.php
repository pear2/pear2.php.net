<?php
namespace PEAR2\Pyrus\Developer\Creator;
class Exception extends \PEAR2\Exception {}