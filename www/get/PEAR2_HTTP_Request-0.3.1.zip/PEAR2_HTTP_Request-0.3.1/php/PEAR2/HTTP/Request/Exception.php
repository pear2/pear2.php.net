<?php
namespace PEAR2\HTTP\Request;
class Exception extends \Exception {
}
