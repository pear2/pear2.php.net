dd if=/dev/zero of=2meg.bin bs=1024 count=2048
