<?php
namespace PEAR2\Templates\Savant;

interface Exception
{

}
?>