<?php
require_once 'PEAR2/Autoload.php';
PEAR2\Autoload::initialize('../src');