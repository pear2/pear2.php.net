<?php
require_once
    '../../PEAR2_Net_Transmitter.git/src/PEAR2/Net/Transmitter/Autoload.php';
require_once '../src/PEAR2/Net/RouterOS/Autoload.php';