<?php

namespace PEAR2\Templates\Savant;

interface MapperInterface
{
    function map($name);
}