<?php
namespace PEAR2\Templates\Savant;

class TemplateException extends \Exception implements Exception {}
?>