<?php echo get_class($context) ?>
<?php echo $context->var1 ?>