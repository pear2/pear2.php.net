<?php

namespace PEAR2\Templates\Savant;

interface FastCompilerInterface extends CompilerInterface
{
}