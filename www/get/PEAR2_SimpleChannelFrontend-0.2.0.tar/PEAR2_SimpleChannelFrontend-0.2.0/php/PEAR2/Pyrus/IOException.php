<?php
namespace PEAR2\Pyrus;

/**
 * The exception that is thrown when an I/O error occurs.
 */
class IOException extends \RuntimeException {}
