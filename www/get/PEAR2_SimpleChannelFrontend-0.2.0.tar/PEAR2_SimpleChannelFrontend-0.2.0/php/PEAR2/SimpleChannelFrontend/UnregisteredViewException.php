<?php
namespace PEAR2\SimpleChannelFrontend;
class UnregisteredViewException extends \UnexpectedValueException implements Exception
{
    
}
?>