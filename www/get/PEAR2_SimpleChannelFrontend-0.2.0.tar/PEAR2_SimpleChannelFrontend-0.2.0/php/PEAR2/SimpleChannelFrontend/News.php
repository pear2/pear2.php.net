<?php
namespace PEAR2\SimpleChannelFrontend;
class News
{
    
}
?>