<?php
namespace testDir1;
class Foo
{
    public static function sayHello()
    {
        return "class testDir1\Foo says hi\n";
    }
}