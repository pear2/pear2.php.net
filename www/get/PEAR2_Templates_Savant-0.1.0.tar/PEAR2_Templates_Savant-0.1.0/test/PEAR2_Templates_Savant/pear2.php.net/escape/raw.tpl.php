<?php
echo $context->__raw('var1');
?>