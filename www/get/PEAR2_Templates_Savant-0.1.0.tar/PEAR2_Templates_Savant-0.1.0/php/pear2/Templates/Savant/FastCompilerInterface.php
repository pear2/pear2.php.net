<?php

namespace pear2\Templates\Savant;

interface FastCompilerInterface extends CompilerInterface
{
}