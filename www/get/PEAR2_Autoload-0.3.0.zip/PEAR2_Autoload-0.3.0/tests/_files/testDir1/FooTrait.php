<?php
namespace testDir1;
trait FooTrait
{
    public static function sayHello()
    {
        return "trait testDir1\FooTrait says hi\n";
    }
}