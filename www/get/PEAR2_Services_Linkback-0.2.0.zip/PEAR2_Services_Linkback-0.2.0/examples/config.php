<?php
$host = 'http://test.bogo';
?>
