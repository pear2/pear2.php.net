<?php

/**
 * RouterOS API client implementation.

 * 
 * RouterOS is the flag product of the company MikroTik and is a powerful router software. One of its many abilities is to allow control over it via an API. This package provides a client for that API, in turn allowing you to use PHP to control RouterOS hosts.
 * 
 * PHP version 5
 * 
 * @category  Net
 * @package   PEAR2_Net_RouterOS
 * @author    Vasil Rangelov <boen.robot@gmail.com>
 * @copyright 2011 Vasil Rangelov
 * @license   http://www.gnu.org/copyleft/lesser.html LGPL License 2.1
 * @version   1.0.0b2
 * @link      http://pear2.php.net/PEAR2_Net_RouterOS
 */
/**
 * The namespace declaration.
 */
namespace PEAR2\Net\RouterOS;

/**
 * Loads a specified class.
 * 
 * Loads a specified class from the namespace.
 * 
 * @param string $class The classname (with namespace) to load.
 * 
 * @return void
 */
function autoload($class)
{
    $namespace = __NAMESPACE__ . '\\';
    if (strpos($class, $namespace) === 0) {
        $path = __DIR__ . DIRECTORY_SEPARATOR .
            strtr(
                substr($class, strlen($namespace)), '\\', DIRECTORY_SEPARATOR
            ) . '.php';
        $file = realpath($path);
        if (is_string($file) && strpos($file, __DIR__) === 0) {
            include_once $file;
        }
    } elseif (strpos($class, 'PEAR2\Net\Transmitter\\') === 0) {
        // @codeCoverageIgnoreStart
        // Testing code explicitly includes the repository version's autoloader.
        $funcs = get_defined_functions();
        if (!in_array('PEAR2\Net\Transmitter\autoload', $funcs['user'], true)) {
            include_once 'PEAR2/Net/Transmitter/Autoload.php';
        }
    }
    // @codeCoverageIgnoreEnd
}

spl_autoload_register(__NAMESPACE__ . '\autoload', true);