<?php
namespace PEAR2\Templates\Savant;

class BadMethodCallException extends \BadMethodCallException implements Exception
{

}