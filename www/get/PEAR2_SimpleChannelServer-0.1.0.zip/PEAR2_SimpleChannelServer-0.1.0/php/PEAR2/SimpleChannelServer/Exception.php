<?php
namespace PEAR2\SimpleChannelServer;
class Exception extends \Exception {}