<?php
echo $context->getRaw('var1');
?>