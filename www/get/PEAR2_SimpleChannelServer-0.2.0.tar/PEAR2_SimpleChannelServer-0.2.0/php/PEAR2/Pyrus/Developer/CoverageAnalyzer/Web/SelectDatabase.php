<?php
namespace PEAR2\Pyrus\Developer\CoverageAnalyzer\Web;
use PEAR2\Pyrus\Developer\CoverageAnalyzer\SourceFile;
class SelectDatabase
{

}