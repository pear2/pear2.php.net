<h3>Installation</h3>
<ol class="instructions">
    <li><code>$>php pyrus.phar channel-discover <?php echo $frontend->getChannel()->name; ?></code></li>
    <li><code>$>php pyrus.phar install <?php echo $context; ?></code></li>
</ol>
