<?php
namespace PEAR2\Pyrus\ChannelFile;
class Exception extends \PEAR2\Exception {}