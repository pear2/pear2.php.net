<?php
namespace PEAR2\Templates\Savant;

class CompilerException extends \Exception implements Exception {}
?>