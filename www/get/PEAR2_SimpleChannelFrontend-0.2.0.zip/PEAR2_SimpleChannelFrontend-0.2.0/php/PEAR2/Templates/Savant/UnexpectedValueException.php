<?php
namespace PEAR2\Templates\Savant;

class UnexpectedValueException extends \UnexpectedValueException implements Exception
{

}
