<?php

namespace PEAR2\Templates\Savant;

interface CompilerInterface
{
    function compile($savant, $name);
}