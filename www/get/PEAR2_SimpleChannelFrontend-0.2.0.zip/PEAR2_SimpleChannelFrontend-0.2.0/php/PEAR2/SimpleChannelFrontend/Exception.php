<?php
namespace PEAR2\SimpleChannelFrontend;
interface Exception{}
?>