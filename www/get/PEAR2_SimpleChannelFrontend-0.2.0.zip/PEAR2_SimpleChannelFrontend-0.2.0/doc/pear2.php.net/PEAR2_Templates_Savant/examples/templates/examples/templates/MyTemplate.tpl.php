<h2>This is MyTemplate.tpl.php</h2>
<p>This represents using a custom output template for an object.</p>
