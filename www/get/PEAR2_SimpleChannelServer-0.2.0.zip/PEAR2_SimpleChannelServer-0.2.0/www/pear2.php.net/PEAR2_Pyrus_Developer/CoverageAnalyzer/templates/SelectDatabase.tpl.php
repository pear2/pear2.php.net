<h2>Please enter the path to a coverage database</h2>
<form name="getdatabase" method="GET" action="<?php echo $parent->context->getRootLink(); ?>">
    <input size="90" type="text" name="setdatabase"/>
    <input type="submit"/>
</form>