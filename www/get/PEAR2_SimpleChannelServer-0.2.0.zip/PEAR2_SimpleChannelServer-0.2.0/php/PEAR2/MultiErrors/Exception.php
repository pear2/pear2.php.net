<?php
namespace PEAR2\MultiErrors;
class Exception extends \PEAR2\Exception {}