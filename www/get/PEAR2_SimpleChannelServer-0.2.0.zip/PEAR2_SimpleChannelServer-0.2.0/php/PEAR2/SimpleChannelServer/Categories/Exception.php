<?php
namespace PEAR2\SimpleChannelServer\Categories;
class Exception extends \Exception {}