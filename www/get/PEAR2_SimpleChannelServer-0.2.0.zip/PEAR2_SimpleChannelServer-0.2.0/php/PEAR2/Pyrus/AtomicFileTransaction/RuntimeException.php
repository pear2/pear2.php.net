<?php
namespace PEAR2\Pyrus\AtomicFileTransaction;

/**
 * Atomic file transaction runtime exception.
 */
class RuntimeException extends \RuntimeException implements Exception
{
}
