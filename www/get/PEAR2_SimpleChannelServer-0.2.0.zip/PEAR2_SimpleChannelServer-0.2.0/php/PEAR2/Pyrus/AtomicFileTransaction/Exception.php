<?php
namespace PEAR2\Pyrus\AtomicFileTransaction;

interface Exception {}
