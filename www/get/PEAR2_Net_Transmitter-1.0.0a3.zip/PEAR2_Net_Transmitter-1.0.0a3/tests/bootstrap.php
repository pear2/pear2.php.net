<?php
require_once 'PEAR2/Autoload.php';
PEAR2\Autoload::initialize('../src');
PEAR2\Autoload::initialize('../../PEAR2_Cache_SHM.git/src');