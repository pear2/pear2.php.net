<?php

namespace PEAR2\Net\RouterOS\Test\Communicator;

use PEAR2\Net\RouterOS\Communicator;
use PHPUnit_Framework_TestCase;

abstract class Unsafe extends PHPUnit_Framework_TestCase
{

    /**
     * @var Communicator
     */
    protected $object;
}
